
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { createPcmBlob, decode, decodeAudioData } from '../utils/audio-utils';
import AudioVisualizer from './AudioVisualizer';

const LiveChat: React.FC = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [transcripts, setTranscripts] = useState<string[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentOutput, setCurrentOutput] = useState('');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const cleanup = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
    }
    sourcesRef.current.forEach(source => source.stop());
    sourcesRef.current.clear();
    setIsConnected(false);
    setIsConnecting(false);
  }, []);

  const handleStop = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
    }
    cleanup();
  };

  const handleStart = async () => {
    try {
      setIsConnecting(true);
      // Create a new GoogleGenAI instance right before making an API call to ensure it uses up-to-date API key.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;

      const analyser = inputCtx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: 'You are a friendly, concise AI companion. Speak naturally and keep responses brief for a smooth conversation.',
        },
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            
            const source = inputCtx.createMediaStreamSource(stream);
            source.connect(analyser);
            
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              // CRITICAL: Solely rely on sessionPromise resolves and then call `session.sendRealtimeInput` as per guidelines.
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcriptions
            if (message.serverContent?.inputTranscription) {
              setCurrentInput(prev => prev + (message.serverContent?.inputTranscription?.text || ''));
            }
            if (message.serverContent?.outputTranscription) {
              setCurrentOutput(prev => prev + (message.serverContent?.outputTranscription?.text || ''));
            }
            if (message.serverContent?.turnComplete) {
              setTranscripts(prev => [...prev, `You: ${currentInput}`, `Gemini: ${currentOutput}`].filter(t => t.split(': ')[1]));
              setCurrentInput('');
              setCurrentOutput('');
            }

            // Handle Audio
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
              });
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error('Live API Error:', e);
            cleanup();
          },
          onclose: () => {
            cleanup();
          }
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start Live session:', err);
      setIsConnecting(false);
      cleanup();
    }
  };

  useEffect(() => {
    return cleanup;
  }, [cleanup]);

  return (
    <div className="flex flex-col items-center justify-center p-6 space-y-8 w-full max-w-2xl mx-auto">
      <div className="relative group">
        {!isConnected && !isConnecting ? (
          <button
            onClick={handleStart}
            className="w-32 h-32 bg-indigo-600 rounded-full flex items-center justify-center text-white text-4xl shadow-lg hover:bg-indigo-700 transition-all duration-300 hover:scale-105"
          >
            <i className="fa-solid fa-microphone"></i>
          </button>
        ) : isConnecting ? (
          <div className="w-32 h-32 bg-indigo-400 rounded-full flex items-center justify-center text-white text-4xl animate-pulse">
            <i className="fa-solid fa-spinner fa-spin"></i>
          </div>
        ) : (
          <button
            onClick={handleStop}
            className="w-32 h-32 bg-red-500 rounded-full flex items-center justify-center text-white text-4xl shadow-lg pulse-animation hover:bg-red-600 transition-all duration-300"
          >
            <i className="fa-solid fa-stop"></i>
          </button>
        )}
      </div>

      <div className="w-full bg-gray-900/50 rounded-2xl p-6 border border-gray-800 shadow-xl min-h-[400px] flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2 max-h-[300px]">
          {transcripts.map((t, i) => (
            <div key={i} className={`p-3 rounded-lg text-sm ${t.startsWith('You:') ? 'bg-indigo-900/30 text-indigo-200 ml-8' : 'bg-gray-800 text-gray-200 mr-8'}`}>
              {t}
            </div>
          ))}
          {(currentInput || currentOutput) && (
            <div className="space-y-2 opacity-70">
              {currentInput && <div className="p-3 rounded-lg text-sm bg-indigo-900/30 text-indigo-200 ml-8 animate-pulse">You: {currentInput}</div>}
              {currentOutput && <div className="p-3 rounded-lg text-sm bg-gray-800 text-gray-200 mr-8 animate-pulse">Gemini: {currentOutput}</div>}
            </div>
          )}
          {transcripts.length === 0 && !currentInput && !currentOutput && (
            <div className="h-full flex items-center justify-center text-gray-500 italic">
              {isConnected ? "Listening for your voice..." : "Tap the microphone to start talking."}
            </div>
          )}
        </div>

        <div className="border-t border-gray-800 pt-4">
          <AudioVisualizer analyser={analyserRef.current} isActive={isConnected} />
        </div>
      </div>
    </div>
  );
};

export default LiveChat;
