
import React, { useState } from 'react';
import { AppMode } from './types';
import LiveChat from './components/LiveChat';
import TextChat from './components/TextChat';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.VOICE);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Header */}
      <header className="p-6 flex items-center justify-between border-b border-gray-800 bg-black/30 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <i className="fa-solid fa-brain text-white text-xl"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              Gemini AI
            </h1>
            <p className="text-[10px] uppercase tracking-widest text-indigo-400 font-semibold">Native Intelligence</p>
          </div>
        </div>

        <nav className="flex bg-gray-900 rounded-full p-1 border border-gray-800">
          <button
            onClick={() => setMode(AppMode.VOICE)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all duration-200 flex items-center space-x-2 ${
              mode === AppMode.VOICE 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-microphone-lines text-xs"></i>
            <span>Voice Mode</span>
          </button>
          <button
            onClick={() => setMode(AppMode.TEXT)}
            className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all duration-200 flex items-center space-x-2 ${
              mode === AppMode.TEXT 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <i className="fa-solid fa-keyboard text-xs"></i>
            <span>Text Chat</span>
          </button>
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-5xl animate-fade-in">
          {mode === AppMode.VOICE ? (
            <div className="text-center space-y-4">
              <div className="mb-8">
                <h2 className="text-3xl font-extrabold text-white mb-2">Real-time Conversation</h2>
                <p className="text-gray-400 max-w-lg mx-auto">Experience low-latency voice interaction with Gemini's native audio capabilities. Just tap to talk.</p>
              </div>
              <LiveChat />
            </div>
          ) : (
            <div className="text-center space-y-4">
              <div className="mb-8">
                <h2 className="text-3xl font-extrabold text-white mb-2">Advanced Text Assistant</h2>
                <p className="text-gray-400 max-w-lg mx-auto">Leverage the power of Gemini 3 Pro for complex reasoning, coding, and creative writing.</p>
              </div>
              <TextChat />
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="p-6 text-center text-gray-500 text-xs border-t border-gray-800">
        <div className="flex items-center justify-center space-x-4 mb-2">
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 bg-green-500 rounded-full"></span>
            <span>API Online</span>
          </span>
          <span className="w-px h-3 bg-gray-800"></span>
          <span>Powered by Gemini 2.5 & 3 Models</span>
        </div>
        <p>&copy; 2024 Gemini Explorer. Built for real-time intelligence.</p>
      </footer>
    </div>
  );
};

export default App;
